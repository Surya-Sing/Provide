// Server Configuration 19-06-2018
var cluster = require('cluster');
const express = require('express');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const passport = require('passport');
const apiRoutes = express.Router();
const cors = require('cors');
const app = express();
var http = require("https");
var cron = require('node-cron');
const multipart = require('connect-multiparty');
const bitso = require('./server/routes/bitso');
const user = require('./server/routes/user');
const User = require('./server/models/user');
const bitstamp = require('./server/routes/bitstamp')
const binance = require('./server/routes/binance')
const bittrex = require('./server/routes/bittrex')
const cex = require('./server/routes/cex')
const btcAlpha = require('./server/routes/btc-alpha')
const coinex = require('./server/routes/coinex')
const exx = require('./server/routes/exx')
const crypto = require('./server/routes/name')
const request = require("request");
const currencyCollection = require('./server/models/currency')
const exchange = require('./server/routes/exchange')
var currency = require('./currency.json');
var customize = require('./customize.json');

var jsonData = require('./sample.json');
var jsonData1 = require('./sample1.json');


const db = require('./database');

require('dotenv').config()
require('./server/config/passport');


app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({
    limit: '1000mb'
}));

app.use(bodyParser.json({
    limit: '1000mb'
}));

app.use(bodyParser.json({
    type: 'application/vnd.api+json'
}));

app.get('/defaultCustomizeColumn', function (req, res) {
    res.json(customize);
})

app.use(passport.initialize());
app.use(multipart());
const enableCORS = function (request, response, next) {
    response.header('Access-Control-Allow-Origin', request.headers.origin);
    response.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    response.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Date, X-Date');
    return next();
};



app.use(cors());
app.use(enableCORS);
//apply the routes to User Module
app.use('/user', user);
app.use('/bitstamp', bitstamp);
app.use('/bitso', bitso);
app.use('/exchange', exchange);
app.use('/cex', cex);
app.use('/coinex', coinex);
app.use('/bittrex', bittrex);
app.use('/btc-alpha', btcAlpha);
app.use('/binance', binance);
app.use('/crypto', crypto);

app.use('/exx', exx);


// route middleware to verify a token
apiRoutes.use(function (req, res, next) {

    // check header or url parameters or post parameters for token
    var token = req.body.token || req.query.token || req.headers['x-access-token'];

    if (token) {
        jwt.verify(token, "tokenValue", function (err, decoded) {
            if (err) {
                return res.json({ success: false, message: 'Failed to authenticate token.' });
            } else {
                // if everything is good, save to request for use in other routes
                req.decoded = decoded;
                next();
            }
        });

    } else {
        // if there is no token return unauthorized error
        return res.status(403).send({
            success: false,
            message: 'No token provided.'
        });

    }
});


apiRoutes.get('/checkAuthentication', function (req, res) {
    res.end("done")
})
apiRoutes.use('/userSetting', user)
apiRoutes.use('/coins', exchange)
app.get('/getData', function (req, res) {
    res.send(jsonData);
})
app.get('/getJSON', function (req, res) {
    res.send(jsonData1);
})
// apply the routes to our application with the prefix /api

app.use('/api', apiRoutes);


function cronTest() {
    //    setInterval(function(){
    //     cex.getData()
    //    },3000)
    cron.schedule('0-59 * * * * *', function () {
        bittrex.getData()
       // bitso.getData()
        bitstamp.getData()
        binance.getBinanceCoinData()
        coinex.getData()
    });
    setTimeout(function () {
        console.log("calling")

        cron.schedule('0-59 * * * * *', function () {
            exchange.coinDetails()
        });
    }, 2000);

    setTimeout(function () {
        cron.schedule('*/2 * * * *', function () {
            exchange.deleteCoinRawData()
        });
        cron.schedule('*/1 * * * *', function () {
            exchange.getMinuteData()
        });
    }, 60000);

}
app.post('/currencyConverter', function (req, res) {
    try{
		var reqCurrency = 'USD' + req.body.converter;
    currencyCollection.findOne({}, function (err, data) {
        var currencyData = data.currency[0];
		var currencyDet =currencyData[reqCurrency]
        res.json({rate:currencyDet})
    })
}catch(e){
	res.statue(400).send("Please try again after some time")
}

})

function currencyReceiver(){
	    var options = {
        method: 'GET',
        url: "http://www.apilayer.net/api/live?access_key=c66c22d1a9ccef7f7cf61f5c36e51a06"
    };
    request(options, function (error, response, body) {
        if (error) {
            //res.send("Please send valid currency name.")
        } else {
            if (body) {
                var data = JSON.parse(body);
                currencyCollection.count({}, function (err, count) {
                    if (count > 0) {
                        var currecyData = new currencyCollection({ currency: data.quotes })
                        currecyData.save(function (error, detail) {
                            if (detail) {
                                currencyCollection.remove({ _id: { $ne: detail._id } }, function (err, details) {
                                  
                                })
                            }
                        })
                    } else {
                        var currecyData = new currencyCollection({ currency: data.quotes })
                        currecyData.save(function (error, detail) {
                        })
                    }

                })
            } else {
               
            }

        }
    });

}

 cron.schedule('0 0 */1 * * *', function () {
            currencyReceiver()
        });


app.get('/getCurrencies', function (req, res) {
    res.send(currency);


})

//cronTest()
module.exports = app;

app.timeout = 0;
app.listen(5687);
console.log('Server running at http://127.0.0.1:' + 5687);


