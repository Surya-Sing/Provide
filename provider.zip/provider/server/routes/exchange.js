

const commonCollection = require('../models/common');
var User = require('../models/user');
const express = require('express');
var request = require("request");
const router = express.Router();
const coinDetailCollection = require('../models/coinDetails');
const minuteCollection = require('../models/minuteData');
const dayCollection = require('../models/dayData');
const exchangeCollection = require('../models/exchangeSummary');

const dayChange = (cb) => {

    // 
    minuteCollection.aggregate([
        { $match: { "datestamp": { $gt: new Date(Date.now() - 24 * 60 * 60 * 1000) } } },//TODO
        { $sort: { price: 1 } },  //TODO  
        { $group: { _id: "$pair", dayVolume: { $avg: "$volume" }, lowestPrice: { $first: "$price" }, highestPrice: { $last: "$price" } } },
        {
            $project: {
                _id: 1,
                "highestPrice": 1,
                "dayVolume": 1,
                "lowestPrice": 1
            }
        }
    ], function (err, data) {
        cb(data)
    })
}

const SevenDayChange = (cb) => {

    var startDate = new Date();
    startDate.setDate(new Date().getDate() - 7);
    startDate.setSeconds(0);
    startDate.setHours(0);
    startDate.setMinutes(0);

    var dateMidnight = new Date(startDate);
    dateMidnight.setHours(23);
    dateMidnight.setMinutes(59);
    dateMidnight.setSeconds(59);
    var aggQuery = [
        {
            $match: {
                $and: [
                    { "datestamp": { $gte: startDate } },
                    { "datestamp": { $lt: dateMidnight } }
                ]
            }
        },

        { $group: { _id: "$pair", price: { $avg: "$price" } } }
    ]
    // console.log(aggQuery)
    coinDetailCollection.aggregate(aggQuery, function (err, data) {
          console.log(data)
        cb(data)
    })
}

const exchangeSummary = (req, res) => {

    exchangeCollection.aggregate([

        { $group: { _id: "$name", total: { $sum: "$volume" },noOfcoins:{$last:"$noOfcoins"} } },
        {
            $project: {
                _id: 1,
                "total": 1,
                noOfcoins:1
            }
        }
    ], function (err, data) {
        if (err || !data) {
            res.status(404).send("No data")
        }
        else {
            var result = []
            let sum = 0;
            data.map((item) => {
                sum += item.total
            })

            data.map((item) => {
                let percent = (((item.total / sum)) * 100).toFixed(2);
                result.push({ name: item._id, volume: item.total, volumePercent: percent, NoOfCoins: item.noOfcoins })
            })
            res.send(result)
        }
    })
}


const getPortfolio = (req, res) => {
	try{
	console.log("Getting call getPortfolio API")
          var id = req.decoded.id;
        var portFolioArray = []
        User.findOne({ _id: id }, function (err, userData) {
                if (userData.portfolio.length > 0) {
                    var portfolioData = userData.portfolio;
                    for (var i = 0; i < portfolioData.length; i++) {
                        portFolioArray.push({ pair: portfolioData[i] })
                    }
                }else{
					return  res.send("No Data")
				}

            var matchArray = [];
            var aggreQuery = [
                {
                    $group:
                    {
                    _id: "$pair",
                    price: { $last: "$price" },
                    pair: { $last: "$pair" },
                    volume: { $last: "$volume" },
                    low: { $last: "$low" },
                    high: { $last: "$high" },
                    dayPricePercent: { $last: "$dayPricePercent" },
                    dayPrice: { $last: "$dayPrice" },
                    dayPriceStatus: { $last: "$dayPriceStatus" },
                    priceStatus: { $last: "$priceStatus" },
                    weeklyChangeStatus: { $last: "$weeklyChangeStatus" },
                    weeklyChange: { $last: "$weeklyChange" },
                    weeklyChangePercent: { $last: "$weeklyChangePercent" },
                    highestPrice: { $last: "$highestPrice" },
                    lowestPrice: { $last: "$lowestPrice" },
                    dayVolume: { $last: "$dayVolume" },

                }
            },
            {
                $lookup:
                {
                    from: "names",
                    localField: "pair",
                    foreignField: "symbol",
                    as: "coindata"
                }
            },
            {
                $unwind: "$coindata"
            },
            {
                $project:
                {
                    "_id": 0,
                    "price": 1,
                    "pair": 1,
                    "low": 1,
                    "high": 1,
                    "volume": 1,
                    "dayPricePercent": 1,
                    "dayPrice": 1,
                    "dayPriceStatus": 1,
                    "priceStatus": 1,
                    "weeklyChangeStatus": 1,
                    "weeklyChange": 1,
                    "weeklyChangePercent": 1,
                    "name": "$coindata.name",
                    "image": "$coindata.image",
                    "highestPrice": 1,
                    "lowestPrice": 1,
                    "dayVolume": 1
                }
            }
            ];

            aggreQuery.unshift({
                $match: {
                    $and: [
                        {
                            $or: portFolioArray
                        }
                    ]
                }
            })
			   if (req.body.hasOwnProperty('search')) {
                var likeString = new RegExp(req.body.search, 'i')
                var searchObj =
                    {
                        $match: { "coindata.name": likeString  }
                    }
    
                aggreQuery.splice((aggreQuery.length - 1), 0, searchObj)
            }
            //console.log(matchArray)
	
    var coinbase = 'usd';  //req.params.id;
    var likeString = new RegExp(coinbase, 'i')

    coinDetailCollection.aggregate(aggreQuery
        ).exec(function (err, data) {
            if (data.length == 0) {
                return res.send("No Data")
            }
            var result = [];
            marketCap(function (cap) {
                data.map((item) => {
                    finalObj = JSON.parse(JSON.stringify(item));
                    //var changesItem = changes.find(x => x._id == item.pair);
                   // if (changesItem != undefined) {
                        var symbolName = (item.name).toLowerCase();
                        var refCapResult = cap.find(capr => capr.name == symbolName);

                        finalObj["marketCapValue"] = refCapResult == undefined ? 0 : (refCapResult.circulating_supply * item.price).toFixed(2);
                        result.push(finalObj)

                  //  }

                })
                res.send(result)
            })


        })
		})
	}catch(e){
		
	}
}

const getusd = (req, res) => {
    try {
		
		if(req.body.hasOwnProperty('from')){
			var from = req.body.from;
		}else{
			var from =0; 
		}
			if(req.body.hasOwnProperty('to')){
			var to = req.body.to;
		}else{
			var to = req.body.to = 20; 
		}
		if(req.body.hasOwnProperty('search')){
			var to = 1500;
		}else{
			var to =req.body.to; 
		}
		var sortObj ={};
		if(req.body.hasOwnProperty('sort')){ 
		
		    sortObj[req.body.sort.key] = req.body.sort.value ; 
		}else{
		 sortObj = { marketCapValue : -1}
		}

		
        
        var matchArray = [];
        var aggreQuery = [
            {
                $group:
                {
                    _id: "$pair",
                    price: { $last: "$price" },
                    pair: { $last: "$pair" },
                    volume: { $last: "$volume" },
                    low: { $last: "$low" },
                    high: { $last: "$high" },
                    dayPricePercent: { $last: "$dayPricePercent" },
                    dayPrice: { $last: "$dayPrice" },
                    dayPriceStatus: { $last: "$dayPriceStatus" },
                    priceStatus: { $last: "$priceStatus" },
                    weeklyChangeStatus: { $last: "$weeklyChangeStatus" },
                    weeklyChange: { $last: "$weeklyChange" },
                    weeklyChangePercent: { $last: "$weeklyChangePercent" },
                    highestPrice: { $last: "$highestPrice" },
                    lowestPrice: { $last: "$lowestPrice" },
                    dayVolume: { $last: "$dayVolume" },
					marketCapValue:{$last: "$marketCapValue"}

                }
            },
			
            {
                $lookup:
                {
                    from: "names",
                    localField: "pair",
                    foreignField: "symbol",
                    as: "coindata"
                }
            },
			
		
			
            {
                $unwind: "$coindata"
            },

            
            {
                $project:
                {
                    "_id": 0,
                    "price": 1,
                    "pair": 1,
                    "low": 1,
                    "high": 1,
                    "volume": 1,
                    "dayPricePercent": 1,
                    "dayPrice": 1,
                    "dayPriceStatus": 1,
                    "priceStatus": 1,
                    "weeklyChangeStatus": 1,
                    "weeklyChange": 1,
                    "weeklyChangePercent": 1,
                    "name": "$coindata.name",
                    "image": "$coindata.image",
                    "highestPrice": 1,
                    "lowestPrice": 1,
                    "dayVolume": 1,
					"marketCapValue":1
                }
            },
				{ $sort : sortObj},
				{ $skip : from },
             { $limit : to}
		
        ];
        if (req.body.hasOwnProperty('filter')) {
            var filterObj = req.body.filter;
            for (var i = 0; i < filterObj.length; i++) {
                var keyMatch = Object.keys(filterObj[i])[0];
                matchArray.push({ [keyMatch]: { $gte: filterObj[i][Object.keys(filterObj[i])].from } })
                matchArray.push({ [keyMatch]: { $lt: filterObj[i][Object.keys(filterObj[i])].to } })
            }
            aggreQuery.unshift({
                $match: {
                    $and: matchArray
                }
            })
            //console.log(matchArray)
        }
		 if (req.body.hasOwnProperty('search')) {
            var likeString = new RegExp(req.body.search, 'i')
            var searchObj =
                {
                    $match: { "coindata.name": likeString  }
                }

            aggreQuery.splice((aggreQuery.length - 1), 0, searchObj)
        }
        coinDetailCollection.aggregate(aggreQuery
       // ).skip(from).limit(to).exec(function (err, data) {
		    ).exec(function (err, data) {
			if(err){
				  return res.send("No Data")
			}
            if (data.length == 0) {
                return res.send("No Data")
            }
			else{
				return res.send(data)
			}
            var result = [];
            marketCap(function (cap) {
                data.map((item) => {
                    finalObj = JSON.parse(JSON.stringify(item));
                    //var changesItem = changes.find(x => x._id == item.pair);
                   // if (changesItem != undefined) {
                        var symbolName = (item.name).toLowerCase();
                        var refCapResult = cap.find(capr => capr.name == symbolName);

                        finalObj["marketCapValue"] = refCapResult == undefined ? 0 : (refCapResult.circulating_supply * item.price).toFixed(2);
                        result.push(finalObj)

                  //  }

                })
                res.send(result)
            })


        })
    } catch (e) {

    }
}

const getusd1 = (req, res) => {
	try{
	console.log("Getting call GETUSD API")
    var matchArray = [];
	var aggreQuery =        [    
            {
                $group:
                {
                    _id: "$pair",
                    price: { $last: "$price" },
                    pair: { $last: "$pair" },
                    volume: { $last: "$volume" },
                    low: { $last: "$low" },
                    high: { $last: "$high" },
                    dayPricePercent: { $last: "$dayPricePercent" },
                    dayPrice: { $last: "$dayPrice" },
                    dayPriceStatus: { $last: "$dayPriceStatus" },
                    priceStatus: { $last: "$priceStatus" },
                    weeklyChangeStatus: { $last: "$weeklyChangeStatus" },
                    weeklyChange: { $last: "$weeklyChange" },
                    weeklyChangePercent: { $last: "$weeklyChangePercent" }
                }
            },
            {
                $lookup:
                {
                    from: "names",
                    localField: "pair",
                    foreignField: "symbol",
                    as: "coindata"
                }
            },
            {
                $unwind: "$coindata"
            },
            {
                $project:
                {
                    "_id": 0,
                    "price": 1,
                    "pair": 1,
                    "low": 1,
                    "high": 1,
                    "volume": 1,
                    "dayPricePercent": 1,
                    "dayPrice": 1,
                    "dayPriceStatus": 1,
                    "priceStatus": 1,
                    "weeklyChangeStatus": 1,
                    "weeklyChange": 1,
                    "weeklyChangePercent": 1,
                    "name": "$coindata.name",
                    "image": "$coindata.image"
                }
            }
        ];
    if (req.body.hasOwnProperty('filter')) {
        var filterObj = req.body.filter;
        // for (key in filterObj) {
            // matchArray.push({ [key]: { $gte: filterObj[key].from } })
            // matchArray.push({ [key]: { $lt: filterObj[key].to } })
        // }
		 for (var i=0; i < filterObj.length ; i++) {
            var keyMatch = Object.keys(filterObj[i])[0];
            matchArray.push({ [keyMatch] : { $gte:filterObj[i][ Object.keys(filterObj[i])].from  } })
            matchArray.push({ [keyMatch] : { $lt: filterObj[i][Object.keys(filterObj[i])].to  } })
        }
		aggreQuery.unshift( {
                $match: {
                    $and: matchArray
                }
            })
        console.log(matchArray)
    }
	
	
    var coinbase = 'usd';  //req.params.id;
    var likeString = new RegExp(coinbase, 'i')

    coinDetailCollection.aggregate(aggreQuery
    ).exec(function (err, data) {
		console.log(err)
	if(data.length == 0){
		//console.log(data)
		return  res.send("No Data")
	}
	dayChange(function (changes) {
            var result = [];
             //console.log(changes)
            marketCap(function (cap) {
                data.map((item) => {
                    //  changes.map((dec) => {
                    finalObj = JSON.parse(JSON.stringify(item));
                    var changesItem = changes.find(x => x._id == item.pair);
                    if (changesItem != undefined) {
                        var symbolName = (item.name).toLowerCase();
                        var refCapResult = cap.find(capr => capr.name == symbolName);

                        finalObj["marketCapValue"] = refCapResult == undefined ? 0 : (refCapResult.circulating_supply * item.price).toFixed(2);

                        finalObj["dayVolume"] = changesItem.dayVolume.toFixed(2),
                            finalObj["lowestPrice"] = changesItem.lowestPrice.toFixed(2),
                            finalObj["highestPrice"] = changesItem.highestPrice.toFixed(2)

                        result.push(finalObj)
                        // console.log(finalObj)
                    }
                    // })
                })
                res.send(result)
            })
        })
        // dayChange(function (changes) {
            // var result = [];
            // // console.log(changes)
            // marketCap(function (cap) {
				// //console.log(cap);
				
                // data.map((item) => {
                    // changes.map((dec) => {
                        // finalObj = JSON.parse(JSON.stringify(item));
                        // if (item.pair == dec._id) {
                            // //   var symbolName = (item.pair).substring(0, 3);
                            // var symbolName = (item.name).toLowerCase();


                            // if (cap) {
                                // for (key in cap) {
                                    // // console.log(cap[key].name)

                                    // var symbolCap = (cap[key].name).toLowerCase();

                                    // if (symbolCap == symbolName) {
                                        // //console.log(cap[key].circulating_supply)
                                        // finalObj["marketCapValue"] = (cap[key].circulating_supply * item.price).toFixed(2);
                                    // }
                                // }
                            // }

                            // finalObj["dayVolume"] = dec.dayVolume.toFixed(2),
                                // finalObj["lowestPrice"] = dec.lowestPrice.toFixed(2),
                                // finalObj["highestPrice"] = dec.highestPrice.toFixed(2)

                            // result.push(finalObj)
                            // //console.log(finalObj)
                        // }
                    // })
                // })
                // res.send(result)
            // })
        // })
    })
	}catch(e){
		
	}
}

const getParticularCoin = (req, res) => {
    // coinDetailCollection.find({pair: /usd$/},function(err,data){
    //     res.send(data)
    // }).sort({_id:1})
    var coinbase = 'usd';  //req.params.id;
    var likeString = new RegExp(coinbase, 'i')
    coinDetailCollection.aggregate(
        [
            {
                $match: { "pair": req.params.id }
            },
            {
                $group:
                {
                    _id: "$pair",
                    price: { $last: "$price" },
                    pair: { $last: "$pair" },
                    volume: { $last: "$volume" },
                    low: { $last: "$low" },
                    high: { $last: "$high" },
                    dayPricePercent: { $last: "$dayPricePercent" },
                    dayPrice: { $last: "$dayPrice" },
                    dayPriceStatus: { $last: "$dayPriceStatus" },
                    priceStatus: { $last: "$priceStatus" },
                    weeklyChangeStatus: { $last: "$weeklyChangeStatus" },
                    weeklyChange: { $last: "$weeklyChange" },
                    weeklyChangePercent: { $last: "$weeklyChangePercent" },
                    highestPrice: { $last: "$highestPrice" },
                    lowestPrice: { $last: "$lowestPrice" },
                    dayVolume: { $last: "$dayVolume" },

                }
            },
            {
                $lookup:
                {
                    from: "names",
                    localField: "pair",
                    foreignField: "symbol",
                    as: "coindata"
                }
            },
            {
                $unwind: "$coindata"
            },
            {
                $project:
                {
                    "_id": 0,
                    "price": 1,
                    "pair": 1,
                    "low": 1,
                    "high": 1,
                    "volume": 1,
                    "dayPricePercent": 1,
                    "dayPrice": 1,
                    "dayPriceStatus": 1,
                    "priceStatus": 1,
                    "weeklyChangeStatus": 1,
                    "weeklyChange": 1,
                    "weeklyChangePercent": 1,
                    "name": "$coindata.name",
                    "image": "$coindata.image",
                    "highestPrice": 1,
                    "lowestPrice": 1,
                    "dayVolume": 1
                }
            }
        ]
    ).exec(function (err, data) {
        res.send(data)
    })

}

const getLastSecData = (req, res) => {
    //console.log(req.body.pair)
    if (req.body.pair) {

        coinDetailCollection.aggregate([

            {
                $project: {
                    _id: 1,
                    pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, datestamp: 1,
                    secs: { $second: '$datestamp' }
                }
            },
            { $match: { pair: req.body.pair } },
            {
                "$sort": {
                    "_id": -1
                }
            },
            {
                "$limit": 1
            }

        ],
            //commonCollection.find({ pair: req.body.pair }, { _id: 0, pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, createdDateTime: 1 },
            function (err, data) {
                //  console.log(err)
                if (data) {
                    var result = []
                    data.map((item) => {
                        finalObj = JSON.parse(JSON.stringify(item));
						 finalObj.date = item.datestamp;
                        finalObj.time = new Date(item.datestamp).valueOf()
                        delete finalObj.datestamp;
                        result.push(finalObj)
                    })

                    res.send(result)
                }

            })
    } else {
        res.status(404).send("Please send valid pair to proceed")
    }


}

const getChart = (req, res) => {
    try {
		var chartInterval,range;
        if (req.body.pair) {
			if(!req.body.interval){
				chartInterval = 30 ;
			}else{
				chartInterval =req.body.interval
			}
			if(!req.body.range){
				range = 3 ;
			}else{
				range =req.body.range
			}
//console.log(range)
            minuteCollection.aggregate([
                { $match: { pair: req.body.pair,
                  datestamp:{  $gte: new Date(new Date().setDate(new Date().getDate()- range))}} },
                {
                    "$group": {
                        "_id": {
                            "year": { "$year": "$datestamp" },
                            "dayOfYear": { "$dayOfYear": "$datestamp" },
                            "hour": { "$hour": "$datestamp" },
                            "interval": {
                                "$subtract": [
                                    { "$minute": "$datestamp" },
                                    { "$mod": [{ "$minute": "$datestamp" }, chartInterval] }
                                ]
                            }
                        },
                        volume: { $first: "$volume" }, open: { $first: "$open" }, close: { $first: "$close" }, price: { $first: "$price" }, high: { $first: "$high" }, low: { $first: "$low" },

                        datestamp: { $first: "$datestamp" }
                    }
                },
                {
                    $project: {
                        _id: 0,
                        pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, datestamp: 1
                    }
                },
               
            ],
                function (err, data) {
                    if (data) {
                        //console.log("Minute collection:" + data.length)
                        dayCollection.aggregate([
						{ $match: { pair: req.body.pair,
                        datestamp:{  $gte: new Date(new Date().setDate(new Date().getDate()- range))}} },
                            {
                                $project: {
                                    _id: 1,
                                    pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, datestamp: 1
                                }
                            },
                             
                        ], function (err, docs) {
                            var result = []
                            // console.log("days collection:" + docs.length)
                             if (docs) {
                                 data.map((item) => {
                                     
                                     finalObj = JSON.parse(JSON.stringify(item));
                                     finalObj.time = new Date(item.datestamp).valueOf()
                                      finalObj.date = item.datestamp;
                                     delete finalObj.datestamp;
                                     result.push(finalObj)
                                 })
                                 docs.map((item) => {
                                     finalObj = JSON.parse(JSON.stringify(item));
                                     finalObj.time = new Date(item.datestamp).valueOf()
                                      finalObj.date = item.datestamp;
                                     delete finalObj.datestamp;
                                     result.push(finalObj)
                                 })
                             setTimeout(function(){
                                 var finalResult = result.sort(function(a, b) { 
                                  a = new Date(a.date);
                                  b = new Date(b.date);
                                   return a <b ? -1 : a > b ? 1 : 0;
                                 })
                                 res.send(finalResult)
                             },0)
                                 
                             } else {
                                 data.map((item) => {
                                     finalObj = JSON.parse(JSON.stringify(item));
                                      finalObj.date = item.datestamp;
                                     finalObj.time = new Date(item.datestamp).valueOf()
                                     delete finalObj.datestamp;
                                     result.push(finalObj)
                                 })
                                 var finalResult = result.sort(function(a, b) { 
                                  a = new Date(a.date);
                                  b = new Date(b.date);
                                  return a <b ? -1 : a > b ? 1 : 0;
                                 })
                                 res.send(finalResult)
                             }
 
 
 
                         })
 
                     } else {
                         res.status(404).send("No Data")
                     }
 
                 })
         } else {
             res.status(404).send("Please send valid pair to proceed")
         }
     } catch (error) {
         res.status(404).send("Please send valid pair to proceed")
     }
}

const getChart1 = (req, res) => {
    try {
		console.log(req.body.pair)
        if (req.body.pair) {

            minuteCollection.aggregate([
		
                {
                    $project: {
                        _id: 1,
                        pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, datestamp: 1
                    }
                },
                { $match: { pair: req.body.pair } }
					
            ],
                function (err, data) {
                    if (data) {
                        //console.log("Minute collection:" + data.length)
                        dayCollection.aggregate([
                            {
                                $project: {
                                    _id: 1,
                                    pair: 1, volume: 1, open: 1, close: 1, price: 1, high: 1, low: 1, datestamp: 1
                                }
                            },
                            { $match: { pair: req.body.pair } }
                        ], function (err, docs) {
                            var result = []
                           // console.log("days collection:" + docs.length)
                            if (docs) {
                                data.map((item) => {
									
                                    finalObj = JSON.parse(JSON.stringify(item));
                                    finalObj.time = new Date(item.datestamp).valueOf()
									 finalObj.date = item.datestamp;
                                    delete finalObj.datestamp;
                                    result.push(finalObj)
                                })
                                docs.map((item) => {
                                    finalObj = JSON.parse(JSON.stringify(item));
                                    finalObj.time = new Date(item.datestamp).valueOf()
									 finalObj.date = item.datestamp;
                                    delete finalObj.datestamp;
                                    result.push(finalObj)
                                })
							setTimeout(function(){
								var finalResult = result.sort(function(a, b) { 
								 a = new Date(a.date);
								 b = new Date(b.date);
								  return a <b ? -1 : a > b ? 1 : 0;
								})
                                res.send(finalResult)
							},0)
                                
                            } else {
                                data.map((item) => {
                                    finalObj = JSON.parse(JSON.stringify(item));
									 finalObj.date = item.datestamp;
                                    finalObj.time = new Date(item.datestamp).valueOf()
                                    delete finalObj.datestamp;
                                    result.push(finalObj)
                                })
								var finalResult = result.sort(function(a, b) { 
								 a = new Date(a.date);
								 b = new Date(b.date);
								 return a <b ? -1 : a > b ? 1 : 0;
								})
                                res.send(finalResult)
                            }



                        })

                    } else {
                        res.status(404).send("No Data")
                    }

                })
        } else {
            res.status(404).send("Please send valid pair to proceed")
        }
    } catch (error) {
        res.status(404).send("Please send valid pair to proceed")
    }
}

const coinDetails = (req, res) => {
    commonCollection.aggregate([
        { $match: { lastRecord: true } },
        { $group: { _id: "$pair", price: { $avg: "$price" }, low: { $avg: "$low" }, high: { $avg: "$high" }, volume: { $avg: "$volume" }, close: { $avg: "$close" }, open: { $avg: "$open" }, "count": { "$sum": 1 }, datestamp: { $last: "$datestamp" } } },
        {
            $project: {
                _id: 1,
                "price": 1,
                "count": 1,
                "low": 1,
                "high": 1,
                "volume": 1,
                "open": 1,
                "close": 1,
                "datestamp": 1
            }
        }
    ], function (err, docs) {
        if (err || !docs) {
            // res.status(404).send("No data")
        }
        else {
			 var totalRecords = docs.length;
			 var count = 0;
            docs.map((data) => {
                 count++
                var change, dayPricePercent, dayPrice, dayPriceStatus;
                coinDetailCollection.findOne({ pair: data._id }).sort({ _id: -1 }).exec(function (err, post) {

                    if (post) {

                        if (post.price < data.price) {
                            change = 'true';
                        } else if (post.price > data.price) {
                            change = 'false';
                        } else {
                            change = 'NC';
                        }
                    } else {
                        change = 'NC';
                    }
                    dayCollection.aggregate([
                        {
                            $match:
                            { pair: data._id }
                        },
                        { $sort: { _id: -1 } },
                        { $limit: 7 },
                        {
                            $group: {
                                _id: "$pair", pair: { $last: "$pair" }, dayPrice: { $first: "$price" }, weeklyPrice: { $last: "$price" }, volume: { $first: "$volume" }
                                , highestPrice: { $first: "$high" }, lowestPrice: { $first: "$low" }
                            }
                        }
                    ]).exec(function (err, days) {
						
						var daysdata = days[0]
                        var latestPrice = Math.floor(data.price * 100) / 100;
                        var weakPrice = Math.floor(daysdata.weeklyPrice * 100) / 100;
                        var oneDayPrice = Math.floor(daysdata.dayPrice * 100) / 100;

                        if (daysdata) {
                            var weeklyChange, weeklyChangeStatus, weeklyChangePercent;
                            weeklyChange = Math.abs(latestPrice - weakPrice); //TODO
                            if (weakPrice < latestPrice) {
                                weeklyChangeStatus = 'true'
                                weeklyChangePercent = (latestPrice / weakPrice)
                            } else if (weakPrice > latestPrice) {
                                weeklyChangePercent = (weakPrice / latestPrice)
                                weeklyChangeStatus = 'false'
                            } else {
                                weeklyChangePercent = 0
                                weeklyChangeStatus = 'NC'
                            }
						
                            dayPrice = Math.abs(data.price - daysdata.dayPrice)
                            var dayVolume = daysdata.volume;
							//console.log(dayVolume)
                            if (oneDayPrice < latestPrice) {
                                dayPricePercent = ((latestPrice / oneDayPrice))
                                dayPriceStatus = 'true';
                            } else if (oneDayPrice > latestPrice) {
                                dayPricePercent = ((oneDayPrice / latestPrice))
                                dayPriceStatus = 'false';
                            } else {
                                dayPricePercent = 0
                                dayPriceStatus = 'NC';
                            }

                        } else {
                            dayPrice = 0;
                            dayPricePercent = 0;
                            dayPriceStatus = 'NC';
                        }
                        var details = new coinDetailCollection({ pair: data._id, price: data.price, dayVolume: dayVolume, volume: data.volume, highestPrice: daysdata.highestPrice, high: data.high,  low: data.low,lowestPrice: daysdata.lowestPrice, open: data.open, close: data.close, priceStatus: change, datestamp: data.datestamp, weeklyChange: weeklyChange, weeklyChangeStatus: weeklyChangeStatus, dayPricePercent: dayPricePercent, weeklyChangePercent: weeklyChangePercent, dayPrice: dayPrice, dayPriceStatus: dayPriceStatus })                       
					   details.save(function (error, detail) {
						   console.log("success")
						  if (totalRecords == count) {
                                commonCollection.updateMany({ lastRecord: true },
                                    { "$set": { "lastRecord": false } }
                                ).exec(function (err, book) {

                                });
                            }
                        })
                    })

                });

            })
        }
    })
}
function marketCap(cb) {
    var options = {
        method: 'GET',
        url: 'https://api.coinmarketcap.com/v2/ticker/',
        json: true
    };

    request(options, function (error, response, body) {
        if (error) {
            console.log(error)
        } else {
             var data = body.data;
            var result = [];

            for (item in data) {
                result.push({ name: (data[item].name).toLowerCase(), circulating_supply: data[item].circulating_supply })

            }
            cb(result)
            //cb(body.data)
        }
    });
}

function deleteCoinRawData() {

    var twoMinuteAgo = new Date( Date.now() - 2000 * 60 );

    commonCollection.remove({datestamp : {$lt : twoMinuteAgo}}, function (err) {
        console.log("Data updated in new collection and deleted from old collection")
    })
    

    // commonCollection.deleteMany({ lastRecord: false }, function (err) {
    //     console.log("Data updated in new collection and deleted from old collection")
    // })
}


function getMinuteData(req, res) {

    var aggQuery = [
        {
            $match: {
                $and: [
                    { "datestamp": { $gte: new Date(new Date(new Date().setMinutes(new Date().getMinutes() - 2)).setSeconds(0)) } },
                    { "datestamp": { $lt: new Date(new Date(new Date().setMinutes(new Date().getMinutes() - 1)).setSeconds(0)) } }
                ]
            }
        },
        { $group: { _id: "$pair", pair: { $last: "$pair" }, price: { $avg: "$price" }, low: { $avg: "$low" }, high: { $avg: "$high" }, volume: { $avg: "$volume" }, close: { $avg: "$close" }, open: { $avg: "$open" }, "count": { "$sum": 1 }, datestamp: { $last: "$datestamp" } } },
        {
            $project: {
                "_id": 0,
                "price": 1,
                "pair": 1,
                "low": 1,
                "high": 1,
                "volume": 1,
                "open": 1,
                "close": 1,
                "datestamp": 1

            }

        }

    ]
    coinDetailCollection.aggregate(aggQuery, function (err, data) {
        if (data) {
            console.log(data)
            var count = 0;
            data.map(function (item) {
                // console.log(item)
                var minuteData = new minuteCollection(item);
                minuteData.save(function (error, detail) {
                    console.log(detail.length)
                    count++
                    if (detail) {

                        // console.log("count:" + count)
                        // console.log("detail.length:" + data.length)
                        if (count == data.length) {
                            coinDetailCollection.remove({
                                $and: [
                                    { "datestamp": { $gte: new Date(new Date(new Date().setMinutes(new Date().getMinutes() - 2)).setSeconds(0)) } },
                                    { "datestamp": { $lt: new Date(new Date(new Date().setMinutes(new Date().getMinutes() - 1)).setSeconds(0)) } }
                                ]
                            }, function (err) {
                                //  console.log(err)
                               // console.log("successfully Deleted")

                            });
                        }

                    }

                })
            })
        }

    })

}

function getMax(req, res) {
    var aggQuery = [
        {
            $group:
            {
                _id: null,
                maxPrice: { $max: "$price" },
				 maxVolume:{$max: "$dayVolume"},
				 marketCapValue:{$max:"$marketCapValue"}
            }
        }
    ]
    coinDetailCollection.aggregate(aggQuery, function (err, data) {
        res.send(data)
    })



}


function getFavourites(req, res) {
    try {
        var id = req.decoded.id;
        var favouritesArray = []
        User.findOne({ _id: id }, function (err, userData) {
   if(err){
	   console.log(err)
	 res.send("No Data")
	 return
    }			
            if (userData.favourites.length > 0) {
                var favData = userData.favourites;
                for (var i = 0; i < favData.length; i++) {
                    favouritesArray.push({ pair: favData[i] })
                }
            } else {
                return res.send("No Data")
            }

           // console.log(favouritesArray)
            var aggreQuery = [
                {
                    $match: {
                        $and: [
                            {
                                $or: favouritesArray
                            }
                        ]
                    }
                },
                {
                    
                $group:
                {
                    _id: "$pair",
                    price: { $last: "$price" },
                    pair: { $last: "$pair" },
                    volume: { $last: "$volume" },
                    low: { $last: "$low" },
                    high: { $last: "$high" },
                    dayPricePercent: { $last: "$dayPricePercent" },
                    dayPrice: { $last: "$dayPrice" },
                    dayPriceStatus: { $last: "$dayPriceStatus" },
                    priceStatus: { $last: "$priceStatus" },
                    weeklyChangeStatus: { $last: "$weeklyChangeStatus" },
                    weeklyChange: { $last: "$weeklyChange" },
                    weeklyChangePercent: { $last: "$weeklyChangePercent" },
                    highestPrice: { $last: "$highestPrice" },
                    lowestPrice: { $last: "$lowestPrice" },
                    dayVolume: { $last: "$dayVolume" },

                }
            },
            {
                $lookup:
                {
                    from: "names",
                    localField: "pair",
                    foreignField: "symbol",
                    as: "coindata"
                }
            },
            {
                $unwind: "$coindata"
            },
            {
                $project:
                {
                    "_id": 0,
                    "price": 1,
                    "pair": 1,
                    "low": 1,
                    "high": 1,
                    "volume": 1,
                    "dayPricePercent": 1,
                    "dayPrice": 1,
                    "dayPriceStatus": 1,
                    "priceStatus": 1,
                    "weeklyChangeStatus": 1,
                    "weeklyChange": 1,
                    "weeklyChangePercent": 1,
                    "name": "$coindata.name",
                    "image": "$coindata.image",
                    "highestPrice": 1,
                    "lowestPrice": 1,
                    "dayVolume": 1
                }
            }
            ];


            coinDetailCollection.aggregate(aggreQuery
        ).exec(function (err, data) {
            if (data.length == 0) {
                return res.send("No Data")
            }
            var result = [];
            marketCap(function (cap) {
                data.map((item) => {
                    finalObj = JSON.parse(JSON.stringify(item));
                    //var changesItem = changes.find(x => x._id == item.pair);
                   // if (changesItem != undefined) {
                        var symbolName = (item.name).toLowerCase();
                        var refCapResult = cap.find(capr => capr.name == symbolName);

                        finalObj["marketCapValue"] = refCapResult == undefined ? 0 : (refCapResult.circulating_supply * item.price).toFixed(2);
                        result.push(finalObj)

                  //  }

                })
                res.send(result)
            })


        })
        })
    } catch (e) {
        res.send("No data")
    }

}
function getAllCoins(req, res) {
    try {
        var id = req.decoded.id;
        var favouritesArray = {}
        User.findOne({ _id: id }, { "favourites": 1 }, function (err, userData) {
            var aggreQuery = [

                {
                $group:
                {
                    _id: "$pair",
                    price: { $last: "$price" },
                    pair: { $last: "$pair" },
                    volume: { $last: "$volume" },
                    low: { $last: "$low" },
                    high: { $last: "$high" },
                    dayPricePercent: { $last: "$dayPricePercent" },
                    dayPrice: { $last: "$dayPrice" },
                    dayPriceStatus: { $last: "$dayPriceStatus" },
                    priceStatus: { $last: "$priceStatus" },
                    weeklyChangeStatus: { $last: "$weeklyChangeStatus" },
                    weeklyChange: { $last: "$weeklyChange" },
                    weeklyChangePercent: { $last: "$weeklyChangePercent" },
                    highestPrice: { $last: "$highestPrice" },
                    lowestPrice: { $last: "$lowestPrice" },
                    dayVolume: { $last: "$dayVolume" },

                }
            },
            {
                $lookup:
                {
                    from: "names",
                    localField: "pair",
                    foreignField: "symbol",
                    as: "coindata"
                }
            },
            {
                $unwind: "$coindata"
            },
            {
                $project:
                {
                    "_id": 0,
                    "price": 1,
                    "pair": 1,
                    "low": 1,
                    "high": 1,
                    "volume": 1,
                    "dayPricePercent": 1,
                    "dayPrice": 1,
                    "dayPriceStatus": 1,
                    "priceStatus": 1,
                    "weeklyChangeStatus": 1,
                    "weeklyChange": 1,
                    "weeklyChangePercent": 1,
                    "name": "$coindata.name",
                    "image": "$coindata.image",
                    "highestPrice": 1,
                    "lowestPrice": 1,
                    "dayVolume": 1
                }
            }
            ];
            if (userData.favourites.length > 0) {
                var favData = userData.favourites;
                var tempArray = [];
                for (var i = 0; i < favData.length; i++) {
                    tempArray.push(favData[i])
                }
                favouritesArray.pair = tempArray
              //  console.log(favouritesArray)
                aggreQuery.unshift({
                    // $match: {
                    //     $and: [
                    //         {
                    //             '$nin': favouritesArray
                    //         }
                    //     ]
                    // }
                    $match: { 'pair': { '$nin': tempArray } }
                })
            }

        coinDetailCollection.aggregate(aggreQuery
        ).exec(function (err, data) {
            if (data.length == 0) {
                return res.send("No Data")
            }
            var result = [];
            marketCap(function (cap) {
                data.map((item) => {
                    finalObj = JSON.parse(JSON.stringify(item));
                    //var changesItem = changes.find(x => x._id == item.pair);
                   // if (changesItem != undefined) {
                        var symbolName = (item.name).toLowerCase();
                        var refCapResult = cap.find(capr => capr.name == symbolName);

                        finalObj["marketCapValue"] = refCapResult == undefined ? 0 : (refCapResult.circulating_supply * item.price).toFixed(2);
                        result.push(finalObj)

                  //  }

                })
                res.send(result)
            })


        })
        })
    } catch (e) {
        res.send("No data")
    }


}

router.route('/getMax').get(getMax)
router.route('/exchangeSummary').get(exchangeSummary)
router.route('/coinDetails').get(coinDetails)
router.route('/getusd/:id').get(getParticularCoin)
router.route('/getFavourites').post(getFavourites)
router.route('/getCoins').post(getAllCoins)
router.route('/SevenDayChange').get(SevenDayChange)
router.route('/getPortfolio').post(getPortfolio)
router.route('/getLastSecData').post(getLastSecData)
router.route('/getusd').post(getusd)
router.route('/getChart').post(getChart)
router.route('/dayChange').post(dayChange)
router.route('/getMinuteData').get(getMinuteData)
module.exports = router;
module.exports.coinDetails = coinDetails;
module.exports.deleteCoinRawData = deleteCoinRawData;
module.exports.getMinuteData = getMinuteData;



